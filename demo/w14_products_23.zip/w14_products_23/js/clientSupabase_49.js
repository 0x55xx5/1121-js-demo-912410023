const SUPABASE_URL = 'https://pyuykdmxtnzzxbomnzbx.supabase.co';
const SUOABASE_ANON_KEY =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InB5dXlrZG14dG56enhib21uemJ4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3MTQzMTAxNzYsImV4cCI6MjAyOTg4NjE3Nn0.CoJHFTOCz97b0a4tF38nw74urq9xB-kiiZF1ZODYEZc';
export const _supabase = supabase.createClient(SUPABASE_URL, SUOABASE_ANON_KEY);
